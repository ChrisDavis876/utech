﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganography
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpenfile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "JPG | *.jpg ";
            openDialog.InitialDirectory = @"C:\Users\Joey and Georgia\Desktop\ComSec";

            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                txtFileSource.Text = openDialog.FileName.ToString();
                pictureBox1.ImageLocation = txtFileSource.Text;
            }
        }

        private void btnEncode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(txtFileSource.Text);
            int i, j;
            for (i = 0; i < img.Width; i++)
            {
                for (j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);

                    if (i < 1 && j < txtMessage.TextLength)
                    {
                        Console.WriteLine("R=[" + i + "][" + j + "] : " + pixel.R);
                        Console.WriteLine("G=[" + i + "][" + j + "] : " + pixel.G);
                        Console.WriteLine("B=[" + i + "][" + j + "] : " + pixel.B);

                        char letter = Convert.ToChar(txtMessage.Text.Substring(j, 1));
                        int value = Convert.ToInt32(letter);
                        Console.WriteLine("Letter :  " + letter + " Value  " + value);

                        img.SetPixel(1, j, Color.FromArgb(pixel.R, pixel.G, value));
                    }
                    if(i == img.Width - 1 && j == img.Height - 1)
                    {
                        img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, txtMessage.TextLength));
                    }
                }
            }
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "JPG | *.jpg ";
            saveFile.InitialDirectory = @"C:\Users\Joey and Georgia\Desktop\ComSec";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                txtFileSource.Text = saveFile.FileName.ToString();
                pictureBox1.ImageLocation = txtFileSource.Text;

                img.Save(txtFileSource.Text);
            }
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(txtFileSource.Text);
            string message = "";

            Color lastpixel = img.GetPixel(img.Width - 1, img.Height - 1);
            int msgLenght = lastpixel.B;

            for (int i = 0; i < img.Width; i++)
            {
                for (int j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);

                    if (i < 1 && j < msgLenght)
                    {
                        int value = pixel.B;
                        char c = Convert.ToChar(value);
                        string letter = System.Text.Encoding.ASCII.GetString(new byte[] { Convert.ToByte(c) });

                        message = message + letter;
                    }
                }
            }
            txtMessage.Text = message;
        }

                  
    }
}
